﻿using IMDbApiLib;
using IMDbApiLib.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace streaming_availability_programm
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    { 

        public MainWindow()
        {
            InitializeComponent();
           _api = new ApiLib("k_tjywpqjv"); //second api key: k_ism9v0e6 third api key: k_y6wgb4c4
        }

         private ApiLib _api;   
        private void searchbtn_Click(object sender, RoutedEventArgs e)
        {       
           searchresultLi.Visibility = Visibility.Visible;

            if (searchall.IsChecked == true) 
            searchforall();
            else if (searchmovie.IsChecked == true)
                searchformovies();
            else if (searchseries.IsChecked == true)
                searchforseries();
            else if (searchepisode.IsChecked == true)
            {
                searchforepisode();
            }
            else if (searchkeyword.IsChecked == true)
            {
                searchforkeyword();
            }
        }

        //Search request throught IMDbApiLib
        private async void searchforall()
        {
            var result = await _api.SearchTitleAsync(searchBar.Text);
            searchresultLi.ItemsSource = result.Results;
            searchresultLi.DisplayMemberPath = "Title";
            searchresultLi.SelectedValuePath = "Id"; //Gives a list item the id of the movie
        }

        /*search movie and search series just optimize the search for movies or series.
         And not filter out only movies or only series*/
        private async void searchformovies()
        {
            var result = await _api.SearchMovieAsync(searchBar.Text);
            searchresultLi.ItemsSource = result.Results;
            searchresultLi.DisplayMemberPath = "Title";
            searchresultLi.SelectedValuePath = "Id";  //Gives a list item the id of the movie
        }
        private async void searchforseries()
        {
            var result = await _api.SearchSeriesAsync(searchBar.Text);
            searchresultLi.ItemsSource = result.Results;
            searchresultLi.DisplayMemberPath = "Title";
            searchresultLi.SelectedValuePath = "Id";  //Gives a list item the id of the movie
        } 

        private async void searchforepisode()
        {
            var result = await _api.SearchEpisodesAsync(searchBar.Text);
            searchresultLi.ItemsSource = result.Results;
            searchresultLi.DisplayMemberPath = "Title";
            searchresultLi.SelectedValuePath = "Id"; //Gives a list item the id of the movie
        }

        private async void searchforkeyword()
        {
            var result = await _api.SearchKeywordAsync(searchBar.Text);
            searchresultLi.ItemsSource = result.Results;
            searchresultLi.DisplayMemberPath = "Title";
            searchresultLi.SelectedValuePath = "Id"; //Gives a list item the id of the movie
        }

        private async void searchrestultLI_selected(object sender, SelectionChangedEventArgs e)
        {
            searchresultLi.Visibility = Visibility.Collapsed;

            if (searchresultLi.SelectedValue != null)
            {
                string id = searchresultLi.SelectedValue.ToString();

                try
                {
                    var titleData = await _api.TitleAsync(id);
                    picturebox.Source = new ImageSourceConverter().ConvertFromString(titleData.Image) as ImageSource;
                    titleofsearch.Text = titleData.Title;
                    plotofsearch.Text = titleData.Plot;
                    ratingofsearch.Text = "IMDB Rating: " + titleData.IMDbRating + "/10";
                    runtimesearch.Text = "Runtime: " + titleData.RuntimeStr;
                    releasedate.Text = "Release Date: " + titleData.Year;
                    agerating.Text = "Content Rating: " + titleData.ContentRating;
                    genressearch.Text = "Genres: " + titleData.Genres;
                }
                catch (Exception ex)
                {
                    // Handle exception or display error message
                    MessageBox.Show("Error occurred: " + ex.Message);
                }
            }
        }


        //Next code block is for checkboxes (Probably not the best solution)
        private void searchall_Checked(object sender, RoutedEventArgs e)
        {
            searchseries.IsChecked = false;
            searchmovie.IsChecked = false;
            searchepisode.IsChecked = false;
            searchkeyword.IsChecked = false;
        }
        private void searchmovie_Checked(object sender, RoutedEventArgs e)
        {
            searchseries.IsChecked = false;
            searchall.IsChecked = false;
            searchepisode.IsChecked = false;
            searchkeyword.IsChecked = false;
        }
        private void searchseries_Checked(object sender, RoutedEventArgs e)
        {
            searchall.IsChecked = false;
            searchmovie.IsChecked = false;
            searchepisode.IsChecked = false;
            searchkeyword.IsChecked = false;
        }
        private void searchepisode_Checked(object sender, RoutedEventArgs e)
        {
            searchall.IsChecked = false;
            searchmovie.IsChecked = false;
            searchseries.IsChecked = false;
            searchkeyword.IsChecked = false;
        }
        private void searchkeyword_Checked(object sender, RoutedEventArgs e)
        {
            searchall.IsChecked = false;
            searchmovie.IsChecked = false;
            searchseries.IsChecked = false;
            searchepisode.IsChecked = false;
        }

   
        //Code for Parameter search
        private void parameterSearchbtn_Click(object sender, RoutedEventArgs e)
        {
            advancedSearch();
        }

        private async void advancedSearch()
        {
            searchresultLi.Visibility = Visibility.Visible;
            var input = new AdvancedSearchInput();
            
            if(genreAction.IsChecked == true)
                input.Genres = AdvancedSearchGenre.Action;
            if (genreAdventure.IsChecked == true)
                input.Genres = AdvancedSearchGenre.Adventure;
            if (genreAnimation.IsChecked == true)
                input.Genres = AdvancedSearchGenre.Animation;
            if (genreComedy.IsChecked == true)
                input.Genres = AdvancedSearchGenre.Comedy;
            if (genreDocumentary.IsChecked == true)
                input.Genres = AdvancedSearchGenre.Documentary;
            if (genreDrama.IsChecked == true)
                input.Genres = AdvancedSearchGenre.Drama;

            if (groupselector.Text == "IMDb Top 100")
                input.TitleGroups = AdvancedSearchTitleGroup.Top_100;
            else if (groupselector.Text == "IMDb Bottom 100")
                input.TitleGroups = AdvancedSearchTitleGroup.Bottom_100;
            else if (groupselector.Text == "Oscar-Winning")
                input.TitleGroups = AdvancedSearchTitleGroup.Oscar_Winner;

            if (pgselector.Text == "all")
                input.USCertificates = null;
            else if (pgselector.Text == "R")
                input.USCertificates = AdvancedSearchUSCertificate.R;
            else if (pgselector.Text == "PG")
                input.USCertificates = AdvancedSearchUSCertificate.PG;
            else if (pgselector.Text == "G")
                input.USCertificates = AdvancedSearchUSCertificate.G;


            string queryString = input.ToString(); // This is for the futur development of the programm 

            var advancedSearchdata = await _api.AdvancedSearchAsync(input); 

            searchresultLi.ItemsSource = advancedSearchdata.Results;
            searchresultLi.DisplayMemberPath = "Title";
            searchresultLi.SelectedValuePath = "Id";

        }
    }
}
